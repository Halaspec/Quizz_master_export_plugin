#!/bin/bash

# PHASE 1 RECUPERER LA DATA DEPUIS LE SERVEUR
# Database connection parameters

DB_HOST=$db_host
DB_USER=$db_user
DB_PASS=$db_password
DB_NAME=$db_name
BLUE='\033[0;34m'
NC='\033[0m' # No Color
RED='"\e[31m'
# SQL query to execute
echo -e $RED "$dest_mail"  "$DB_HOST $DB_NAME"  "$DB_USER"  "$DB_PASS" "$db_port" $NC
SQL_QUERY="select quiz_results from wp_mlw_results where quiz_id = 1;;"
SQL_QUERY_2="select time_taken_real from wp_mlw_results where quiz_id = 1;;"
counter=1


echo "" > reponses_data.txt
echo "" > questions_data.txt
echo "" >./sortie/output.csv
echo "" >./sortie/output2.csv

# Execute SQL query and save the result to CSV file
mysql -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASS" -D"$DB_NAME" -e"$SQL_QUERY_2" -P "$db_port" --batch --raw > "date.txt"
# Execute the MySQL query and process each row
mysql -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASS" -D"$DB_NAME" -e"$SQL_QUERY" -P "30363" | while read -r column1; do
    # Process each row here
    echo -e $column1  "\n \n"| grep -o -P 'user_answer".*?s:[0-9]+:"[a-zA-Z]+.*?";.*?}'  >> reponses_data.txt
         
    if ((counter < 3 )); then 
        csv_line=""
         # Extract question text between quotes
         echo -e $column1  "\n \n"| grep -o -P 'question_title";s:\d+:"(.*?)";'  > questions_data.txt
         while IFS= read -r line; do
                # Check if the line contains "question_title"
                question=$(echo "$line" |grep -o -P 'question_title";s:\d+:"(.*?)";'| grep -o -P  ':".*?";' | sed 's/^.\(.*\).$/\1/' | grep -v '"input"' | grep -v '"correct_answer"')
                # Append JSON object to the output
                # Concatenate questions with a comma (CSV format)
                csv_line="${csv_line}${question},"   
        done < "questions_data.txt"
        echo -e ${csv_line%,}  > ./sortie/output.csv
        
        if ((counter < 2 )); then 
                # Extract date inscription text between quotes
                csv_line=""
                echo "Date inscription," > ./sortie/output2.csv
                tail -n +2 "date.txt" | while IFS= read -r line; do
                       echo $line "," >> ./sortie/output2.csv
                done 
        fi
        csv_line=""
    fi
    
    
    while IFS= read -r line; do
        # Extract asnwer text between quotes
        reponse=$(echo "$line" |grep -o -P 'user_answer".*?s:[0-9]+:"[a-zA-Z]+.*?";.*?}'| grep -o -P  ':".*?";' | sed 's/^.\(.*\).$/\1/' | grep -v '"input"' | grep -v '"correct_answer"')
        # Append JSON object to the output
        # reponse="${reponse// / et }"
        # Concatenate questions with a comma (CSV format)
        csv_line="${csv_line}${reponse},"
    done < "reponses_data.txt"
   
    # append answer in csv file    
    echo -e ${csv_line%,}  >> ./sortie/output.csv
    # init var
    csv_line=""
    rm reponses_data.txt
    ((counter++))
done


# Fusionner les deux fichier csv
paste ./sortie/output2.csv ./sortie/output.csv > ./sortie/fusion.csv


pip install csvkit
# Convertir CSV en JSON
csvjson "./sortie/fusion.csv" > temp.json

# Convertir JSON en XLSX
in2csv temp.json > ./sortie/output.xlsx

# Supprimer le fichier temporaire JSON
rm temp.json
rm ./sortie/output.csv
rm ./sortie/output2.csv

if [ -z "$dest_mail" ]; then
    echo "pas de valeur"
    # Si l'argument est vide, donne-lui une valeur par défaut
    dest_mail="hs@bettanedesseauve.com"
fi

python3 send_email.py $dest_mail
