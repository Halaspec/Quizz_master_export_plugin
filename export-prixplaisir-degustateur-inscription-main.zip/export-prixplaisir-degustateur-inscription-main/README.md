# export-prixplaisir-degustateur-inscription

Pour faire un test

docker run --name prix -e dest_mail="email" -e  db_port="port" -e db_host="ip" -e db_name="db_name" -e db_user="user" -e  db_password="mdp" -v ./sortie:/sortie registry.gitlab.com/bettanedesseauve/docker/export-prixplaisir-degustateur-inscription

-  Modele json pour lancer un job kubernetes le reste a edit les variables du job ! 
-  Le pv est fixe /docker-storage/2bds/extranet-dev-bd-com/degustateurs 
-  Api en Basic reste a le choper via Rancher ! 
