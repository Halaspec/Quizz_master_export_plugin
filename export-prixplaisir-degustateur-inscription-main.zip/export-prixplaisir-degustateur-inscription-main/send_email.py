
import smtplib
import sys
from email.message import EmailMessage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# Email configuration
sender_email = "prixplaisir@bettanedesseauve.com"
recipient_email = argument1 = sys.argv[1]
email_subject = "Inscription dégustateur"
email_body = "This is a test email with an attachment. Powered by Halaspec"

# File to be sent
file_path = "./sortie/output.xlsx"

# Create an email message
msg = MIMEMultipart()
msg["From"] = sender_email
msg["To"] = recipient_email
msg["Subject"] = email_subject
msg.attach(MIMEText(email_body, "plain"))

# Attach the file
with open(file_path, "rb") as file:
    part = MIMEBase("application", "octet-stream")
    part.set_payload(file.read())
    encoders.encode_base64(part)
    part.add_header("Content-Disposition", f"attachment; filename= {file_path}")
    msg.attach(part)

# Send the email
try:
    server = smtplib.SMTP("10.0.1.50", 25)  # Replace with your SMTP server address and port
    server.sendmail(sender_email, recipient_email, msg.as_string())
    server.quit()
    print("Email sent successfully with attachment.")
except Exception as e:
    print(f"Failed to send email: {e}")
